package com.flipball.game;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ir.tapsell.mediation.Tapsell;
import ir.tapsell.mediation.ad.AdStateListener;
import ir.tapsell.mediation.ad.request.BannerSize;
import ir.tapsell.mediation.ad.request.RequestResultListener;
import ir.tapsell.mediation.ad.show.AdShowCompletionState;
import ir.tapsell.mediation.ad.views.banner.BannerContainer;

/**
 * پل بین JavaScript بازی (window.tapsell در tapsell-bridge.js) و Tapsell Mobile Ads SDK.
 * SDK به‌طور خودکار مقداردهی می‌شود (ContentProvider)، پس نیازی به initialize دستی نیست.
 * همه‌ی فراخوانی‌های SDK روی ترد اصلی انجام می‌شود.
 *
 * جایزه فقط وقتی به بازی داده می‌شود که SDK تپسل onRewarded را اعلام کند
 * یا تبلیغ با وضعیت COMPLETED (کامل دیده شده) بسته شود.
 */
public class TapsellBridge {

    private static final String TAG = "TapsellBridge";
    private static final String KIND_INTERSTITIAL = "interstitial";

    private final Activity activity;
    private final WebView webView;
    private final BannerContainer bannerContainer;
    private final Handler main = new Handler(Looper.getMainLooper());

    private boolean initCalled = false;
    private boolean ready = false;
    private final List<Runnable> pending = new ArrayList<>();

    private final Map<String, String> kinds = new HashMap<>();   // adId -> rewarded | interstitial
    private final Set<String> rewarded = new HashSet<>();        // adId هایی که جایزه‌شان تأیید شده
    private final Set<String> finished = new HashSet<>();        // جلوگیری از ارسال دوباره‌ی پایان تبلیغ
    private volatile boolean adShowing = false;

    private String bannerAdId = null;
    private boolean bannerWanted = true;
    private boolean bannerRequested = false;

    public TapsellBridge(Activity activity, WebView webView, BannerContainer bannerContainer) {
        this.activity = activity;
        this.webView = webView;
        this.bannerContainer = bannerContainer;
    }

    public boolean isAdShowing() {
        return adShowing;
    }

    public void destroy() {
        main.removeCallbacksAndMessages(null);
        try {
            if (bannerAdId != null) Tapsell.destroyBannerAd(bannerAdId);
        } catch (Throwable t) {
            Log.w(TAG, "destroy banner failed", t);
        }
    }

    // ------------------------------------------------------------------ Init

    /** SDK خودکار مقداردهی می‌شود؛ این تابع فقط درخواست‌های صف‌شده را بعد از کمی صبر آزاد می‌کند. */
    @JavascriptInterface
    public void initialize(final String appKey) {
        main.post(() -> {
            if (initCalled) return;
            initCalled = true;
            try {
                Tapsell.setInitializationListener(() -> main.post(this::markReady));
            } catch (Throwable t) {
                Log.w(TAG, "setInitializationListener failed", t);
            }
            main.postDelayed(this::markReady, 1500);
        });
    }

    private void markReady() {
        if (ready) return;
        ready = true;
        List<Runnable> copy = new ArrayList<>(pending);
        pending.clear();
        for (Runnable r : copy) r.run();
    }

    private void whenReady(Runnable r) {
        if (ready) r.run();
        else pending.add(r);
    }

    // --------------------------------------------------- Rewarded / Interstitial

    @JavascriptInterface
    public void requestAd(final String reqId, final String zoneId, final String kind) {
        main.post(() -> whenReady(() -> doRequestAd(reqId, zoneId, kind)));
    }

    private void doRequestAd(final String reqId, final String zoneId, final String kind) {
        RequestResultListener listener = new RequestResultListener() {
            public void onSuccess(String adId) {
                kinds.put(adId, kind);
                emitRequest(reqId, "onAdAvailable", adId, null);
            }

            // نسخه‌های مختلف SDK امضای متفاوتی دارند؛ هر دو را پوشش می‌دهیم
            public void onFailure() {
                emitRequest(reqId, "onNoAdAvailable", null, "no ad available");
            }

            public void onFailure(String message) {
                emitRequest(reqId, "onNoAdAvailable", null, message);
            }
        };
        try {
            if (KIND_INTERSTITIAL.equals(kind)) {
                Tapsell.requestInterstitialAd(zoneId, listener);
            } else {
                Tapsell.requestRewardedAd(zoneId, listener);
            }
        } catch (Throwable t) {
            emitRequest(reqId, "onError", null, String.valueOf(t));
        }
    }

    @JavascriptInterface
    public void showAd(final String adId) {
        main.post(() -> {
            String kind = kinds.get(adId);
            try {
                if (KIND_INTERSTITIAL.equals(kind)) {
                    Tapsell.showInterstitialAd(adId, activity, new AdStateListener.Interstitial() {
                        public void onAdImpression() {
                            adShowing = true;
                            emitShow(adId, "onOpened", null);
                        }

                        public void onAdClicked() {
                        }

                        public void onAdClosed(AdShowCompletionState state) {
                            handleClosed(adId, state);
                        }

                        public void onAdFailed(String message) {
                            handleFailed(adId, message);
                        }
                    });
                } else {
                    Tapsell.showRewardedAd(adId, activity, new AdStateListener.Rewarded() {
                        public void onAdImpression() {
                            adShowing = true;
                            emitShow(adId, "onOpened", null);
                        }

                        public void onAdClicked() {
                        }

                        public void onRewarded() {
                            rewarded.add(adId);
                        }

                        public void onAdClosed(AdShowCompletionState state) {
                            handleClosed(adId, state);
                        }

                        public void onAdFailed(String message) {
                            handleFailed(adId, message);
                        }
                    });
                }
            } catch (Throwable t) {
                handleFailed(adId, String.valueOf(t));
            }
        });
    }

    private void handleClosed(final String adId, AdShowCompletionState state) {
        adShowing = false;
        if (state == AdShowCompletionState.COMPLETED) rewarded.add(adId);
        emitShow(adId, "onClosed", null);
        // کمی صبر تا اگر onRewarded دیرتر رسید از دست نرود
        main.postDelayed(() -> finishAd(adId), 350);
    }

    private void handleFailed(String adId, String message) {
        adShowing = false;
        emitShow(adId, "onError", message);
        finishAd(adId);
    }

    private void finishAd(String adId) {
        if (!finished.add(adId)) return;
        boolean wasRewarded = rewarded.remove(adId);
        boolean isRewardedKind = !KIND_INTERSTITIAL.equals(kinds.remove(adId));
        JSONObject o = new JSONObject();
        try {
            o.put("action", "onAdShowFinished");
            o.put("adId", adId);
            o.put("completed", isRewardedKind ? wasRewarded : true);
            o.put("rewarded", isRewardedKind && wasRewarded);
        } catch (JSONException ignored) {
        }
        js("window.__tapsellNative&&window.__tapsellNative.onFinished(" + o + ")");
    }

    // ------------------------------------------------------------------ Banner

    @JavascriptInterface
    public void requestBanner(final String zoneId) {
        main.post(() -> {
            bannerWanted = true;
            if (bannerRequested) {
                applyBannerVisibility();
                return;
            }
            bannerRequested = true;
            whenReady(() -> loadBanner(zoneId, 0));
        });
    }

    @JavascriptInterface
    public void setBannerVisible(final boolean visible) {
        main.post(() -> {
            bannerWanted = visible;
            applyBannerVisibility();
        });
    }

    private void loadBanner(final String zoneId, final int attempt) {
        final Runnable retry = () -> {
            if (attempt < 3) {
                main.postDelayed(() -> loadBanner(zoneId, attempt + 1), 8000L * (attempt + 1));
            }
        };
        try {
            Tapsell.requestBannerAd(zoneId, BannerSize.BANNER_320_50, new RequestResultListener() {
                public void onSuccess(String adId) {
                    bannerAdId = adId;
                    try {
                        Tapsell.showBannerAd(adId, bannerContainer, activity, new AdStateListener.Banner() {
                            public void onAdImpression() {
                            }

                            public void onAdClicked() {
                            }

                            public void onAdFailed(String message) {
                                Log.w(TAG, "banner show failed: " + message);
                            }
                        });
                    } catch (Throwable t) {
                        Log.w(TAG, "banner show crashed", t);
                    }
                    applyBannerVisibility();
                }

                public void onFailure() {
                    Log.w(TAG, "banner request failed");
                    retry.run();
                }

                public void onFailure(String message) {
                    Log.w(TAG, "banner request failed: " + message);
                    retry.run();
                }
            });
        } catch (Throwable t) {
            Log.w(TAG, "banner request crashed", t);
        }
    }

    private void applyBannerVisibility() {
        bannerContainer.setVisibility(bannerWanted && bannerAdId != null ? View.VISIBLE : View.GONE);
    }

    // ------------------------------------------------------------------ JS events

    private void emitRequest(String reqId, String action, String adId, String error) {
        JSONObject o = new JSONObject();
        try {
            o.put("action", action);
            if (adId != null) o.put("adId", adId);
            if (error != null) o.put("error", error);
        } catch (JSONException ignored) {
        }
        js("window.__tapsellNative&&window.__tapsellNative.onRequest(" + JSONObject.quote(reqId) + "," + o + ")");
    }

    private void emitShow(String adId, String action, String error) {
        JSONObject o = new JSONObject();
        try {
            o.put("action", action);
            o.put("adId", adId);
            if (error != null) o.put("error", error);
        } catch (JSONException ignored) {
        }
        js("window.__tapsellNative&&window.__tapsellNative.onShow(" + JSONObject.quote(adId) + "," + o + ")");
    }

    private void js(final String script) {
        main.post(() -> webView.evaluateJavascript(script, null));
    }
}
