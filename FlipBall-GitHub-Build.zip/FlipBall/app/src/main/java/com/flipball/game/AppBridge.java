package com.flipball.game;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/** توابع کمکی بومی برای بازی (ذخیره فایل پشتیبان). */
public class AppBridge {

    private final Context context;

    public AppBridge(Context context) {
        this.context = context.getApplicationContext();
    }

    /**
     * ذخیره‌ی متن در پوشه Downloads (اندروید ۱۰ به بالا) یا پوشه‌ی اختصاصی برنامه (نسخه‌های قدیمی‌تر).
     * @return true در صورت موفقیت
     */
    @JavascriptInterface
    public boolean saveTextFile(String name, String content) {
        try {
            String safeName = (name == null ? "flip-ball-save.json" : name).replaceAll("[^A-Za-z0-9._-]", "_");
            byte[] data = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);

            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                values.put(MediaStore.Downloads.MIME_TYPE, "application/json");
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = context.getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) return false;
                try (OutputStream os = context.getContentResolver().openOutputStream(uri)) {
                    if (os == null) return false;
                    os.write(data);
                }
            } else {
                File dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) return false;
                if (!dir.exists() && !dir.mkdirs()) return false;
                try (FileOutputStream os = new FileOutputStream(new File(dir, safeName))) {
                    os.write(data);
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
