/**
 * tapsell-bridge.js
 * ------------------------------------------------------------------
 * پل سازگاری: API قدیمی window.tapsell (که بازی از آن استفاده می‌کند)
 * را به Tapsell Plus SDK بومی اندروید (از طریق TapsellNative) وصل می‌کند.
 * در مرورگر معمولی (بدون TapsellNative) هیچ کاری نمی‌کند و window.tapsell تعریف نمی‌شود.
 */
(function () {
  'use strict';
  var N = window.TapsellNative;
  if (!N) { return; }

  var seq = 0;
  var pendingReq = {};
  var showCbs = {};
  var rewardCb = null;
  // اگر درخواست تبلیغ پر نشد، چند بار با فاصله دوباره تلاش می‌کنیم
  var RETRY_DELAYS = [6000, 12000, 20000];

  function cfg() { return window.FLIPBALL_TAPSELL_CONFIG || {}; }
  function safe(fn, arg) {
    try { if (typeof fn === 'function') fn(arg); }
    catch (e) { console.warn('[tapsell-bridge]', e); }
  }
  function send(entry) { N.requestAd(entry.id, entry.zoneId, entry.kind); }

  window.__tapsellNative = {
    onRequest: function (id, res) {
      var e = pendingReq[id];
      if (!e) return;
      if (res && res.action === 'onAdAvailable') {
        delete pendingReq[id];
        safe(e.cb, res);
        return;
      }
      if (e.tries < RETRY_DELAYS.length) {
        var delay = RETRY_DELAYS[e.tries++];
        setTimeout(function () { send(e); }, delay);
        return;
      }
      delete pendingReq[id];
      safe(e.cb, res);
    },
    onShow: function (adId, res) {
      var cb = showCbs[adId];
      safe(cb, res);
      if (res && (res.action === 'onClosed' || res.action === 'onError')) delete showCbs[adId];
    },
    onFinished: function (res) {
      safe(rewardCb, res);
    }
  };

  window.tapsell = {
    isNativeBridge: true,

    initialize: function (appKey) { N.initialize(String(appKey)); },

    setRewardCallback: function (cb) { rewardCb = cb; },

    // requestAd(zoneId, cached, callback)
    requestAd: function (zoneId, cached, cb) {
      var id = String(++seq);
      var c = cfg();
      var kind = (c.interstitialZoneId && String(zoneId) === String(c.interstitialZoneId))
        ? 'interstitial' : 'rewarded';
      var entry = { id: id, zoneId: String(zoneId), kind: kind, cb: cb, tries: 0 };
      pendingReq[id] = entry;
      send(entry);
    },

    // showAd(adId, backDisabled, immersive, rotation, showDialog, callback)
    showAd: function (adId, backDisabled, immersive, rotation, showDialog, cb) {
      if (typeof cb === 'function') showCbs[adId] = cb;
      N.showAd(String(adId));
    },

    requestBannerAd: function (zoneId /*, size, gravityV, gravityH */) {
      N.requestBanner(String(zoneId));
    },
    showBanner: function () { N.setBannerVisible(true); },
    hideBanner: function () { N.setBannerVisible(false); }
  };
})();
