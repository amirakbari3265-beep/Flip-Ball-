-keepclassmembers class com.flipball.game.TapsellBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keepclassmembers class com.flipball.game.AppBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class ir.tapsell.** { *; }
-dontwarn ir.tapsell.**
