# FLIP BALL – پروژه Android Studio (با تبلیغات تپسل)

بازی HTML داخل WebView اجرا می‌شود و تبلیغات با **Tapsell Mobile Ads SDK** (طبق مستندات developer.tapsell.ir) نمایش داده می‌شود.

## اجرا و ساخت APK
1. Android Studio نسخه‌ی Koala (2024.1) یا جدیدتر (JDK 17 همراه خودش).
2. `File ▸ Open` ← پوشه‌ی `FlipBall` ← صبر برای Gradle Sync (اینترنت لازم است).
3. بالای `app/build.gradle` این‌ها را چک کن:
   - `tapsellVersion` ← **آخرین نسخه‌ی SDK را از صفحه‌ی Quick Start مستندات تپسل کپی کن**
   - `tapsellAppId` ← شناسه/کلید اپ از پنل تپسل
   - `tapsellMarket` ← بازار انتشار (CafeBazaar / Myket / GooglePlay)
   - `applicationId` ← باید با نام پکیج اپ ثبت‌شده در پنل تپسل یکی باشد
4. برای تست: گوشی واقعی + اینترنت ← Run.
5. برای APK نهایی: `Build ▸ Generate Signed Bundle / APK ▸ APK` (Keystore را نگه دار).

## Zone ها
در بالای `app/src/main/assets/www/index.html` (`FLIPBALL_TAPSELL_CONFIG`):
- `rewardedZoneId` ← تبلیغ جایزه‌ای
- `bannerZoneId` ← بنر ۳۲۰×۵۰
- `interstitialZoneId` ← خالی؛ اگر Zone تمام‌صفحه داری اینجا بگذار
Zone ها باید در همان پنل/اپی ساخته شده باشند که `tapsellAppId` مال آن است.

## ساختار
- `MainActivity.java` – WebView تمام‌صفحه، دکمه بازگشت (دوبار برای خروج)، انتخاب فایل پشتیبان
- `TapsellBridge.java` – اتصال JavaScript ↔ Tapsell SDK (Rewarded / Interstitial / Banner)
- `assets/www/tapsell-bridge.js` – `window.tapsell` بازی را به پل بومی وصل می‌کند
- `AppBridge.java` – ذخیره‌ی فایل پشتیبان

## اگر Sync یا Build خطا داد
- «placeholder substitution» ← اسم placeholder در مستندات نسخه‌ی جدید فرق دارد؛ همان اسم را در `manifestPlaceholders` بگذار.
- نسخه پیدا نشد ← `tapsellVersion` را با مستندات هماهنگ کن.
- خطای امضای متد در `TapsellBridge.java` ← با Alt+Enter یا مستندات اصلاح کن.
